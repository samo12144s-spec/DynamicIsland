package com.samo.island

import android.app.PendingIntent
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.media.session.MediaController
import android.os.Handler
import android.os.Looper

/** Everything the island can show. */
sealed class IslandEvent {
    data class Notif(
        val title: String,
        val text: String,
        val icon: Drawable?,
        val intent: PendingIntent?,
        val pkg: String,
    ) : IslandEvent()

    data class Charging(val level: Int, val plugged: Boolean) : IslandEvent()

    data class Media(
        val title: String,
        val artist: String,
        val art: Bitmap?,
        val color: Int,
        val playing: Boolean,
        val pkg: String,
    ) : IslandEvent()

    object MediaGone : IslandEvent()
}

/** In-process bridge between the notification listener, the overlay service and the settings screen. */
object IslandBus {
    private val main = Handler(Looper.getMainLooper())

    /** Set by IslandService while it is running. */
    var listener: ((IslandEvent) -> Unit)? = null

    /** Active media session, used for play / pause / skip buttons. */
    var controller: MediaController? = null

    var lastMedia: IslandEvent.Media? = null
        private set

    val serviceRunning: Boolean get() = listener != null

    fun post(e: IslandEvent) {
        main.post {
            when (e) {
                is IslandEvent.Media -> lastMedia = e
                IslandEvent.MediaGone -> lastMedia = null
                else -> Unit
            }
            listener?.invoke(e)
        }
    }
}

object Prefs {
    const val Y = "y"          // dp from top of screen
    const val X = "x"          // dp horizontal offset
    const val IW = "iw"        // idle width dp
    const val IH = "ih"        // idle height dp
    const val IDLE = "idle"
    const val NOTIF = "notif"
    const val MEDIA = "media"
    const val CHARGE = "charge"

    const val DEF_Y = 6
    const val DEF_X = 0
    const val DEF_IW = 90
    const val DEF_IH = 28

    fun get(c: Context): SharedPreferences =
        c.getSharedPreferences("island", Context.MODE_PRIVATE)
}
