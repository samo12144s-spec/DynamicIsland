package com.samo.island

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.abs
import kotlin.math.sin

/** Little animated equalizer bars, like the iPhone "now playing" indicator. */
class WaveBars(context: Context) : View(context) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private var t = 0f

    private val anim = ValueAnimator.ofFloat(0f, (2 * Math.PI).toFloat()).apply {
        duration = 1100
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            t = it.animatedValue as Float
            invalidate()
        }
    }

    var color: Int = Color.WHITE
        set(v) {
            field = v
            paint.color = v
            invalidate()
        }

    var playing: Boolean = false
        set(v) {
            field = v
            if (v && isAttachedToWindow) {
                if (!anim.isStarted) anim.start()
            } else {
                anim.cancel()
            }
            invalidate()
        }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (playing && !anim.isStarted) anim.start()
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val n = 4
        val bw = width / (n * 2f - 1f)
        for (i in 0 until n) {
            val amp = if (playing) 0.3f + 0.7f * abs(sin(t + i * 1.4f)) else 0.25f
            val bh = height * amp
            val x = i * bw * 2f
            val top = (height - bh) / 2f
            canvas.drawRoundRect(x, top, x + bw, top + bh, bw / 2f, bw / 2f, paint)
        }
    }
}
