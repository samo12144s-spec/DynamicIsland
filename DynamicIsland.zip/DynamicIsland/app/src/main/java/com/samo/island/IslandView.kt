package com.samo.island

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min

private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT

/**
 * The black pill. It morphs between: idle (around the camera), compact (icon + info),
 * and expanded (big card with media controls).
 */
@SuppressLint("ViewConstructor", "ClickableViewAccessibility")
class IslandView(context: Context) : FrameLayout(context) {

    private val density = resources.displayMetrics.density
    private fun px(v: Float): Int = (v * density).toInt()

    var idleW: Int = px(Prefs.DEF_IW.toFloat())
    var idleH: Int = px(Prefs.DEF_IH.toFloat())

    var tapAction: () -> Unit = {}
    var longAction: () -> Unit = {}
    var outsideAction: () -> Unit = {}
    var swipeUpAction: () -> Unit = {}
    var prevAction: () -> Unit = {}
    var playAction: () -> Unit = {}
    var nextAction: () -> Unit = {}

    private val bg = GradientDrawable().apply {
        setColor(Color.BLACK)
        cornerRadius = 14f * density
    }

    private val pill = FrameLayout(context).apply {
        background = bg
        clipToOutline = true
        layoutDirection = View.LAYOUT_DIRECTION_LTR
    }

    // ---------- compact ----------
    private val cIcon = ImageView(context).apply {
        scaleType = ImageView.ScaleType.CENTER_CROP
        rounded(this, 7f * density)
    }
    private val cLabel = text(13f, Color.WHITE, true)
    private val cRight = text(13f, Color.WHITE, true)
    private val cBars = WaveBars(context)

    private val compact = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(px(8f), 0, px(12f), 0)
        alpha = 0f
        visibility = View.GONE
        addView(cIcon, LinearLayout.LayoutParams(px(22f), px(22f)))
        addView(cLabel, LinearLayout.LayoutParams(0, WRAP, 1f).apply {
            marginStart = px(8f); marginEnd = px(8f)
        })
        addView(cRight, LinearLayout.LayoutParams(WRAP, WRAP))
        addView(cBars, LinearLayout.LayoutParams(px(20f), px(14f)))
    }

    // ---------- expanded ----------
    private val eIcon = ImageView(context).apply {
        scaleType = ImageView.ScaleType.CENTER_CROP
        rounded(this, 12f * density)
    }
    private val eTitle = text(16f, Color.WHITE, true)
    private val eSub = text(13f, Color.parseColor("#B3FFFFFF"), false).apply { maxLines = 2 }
    private val eBars = WaveBars(context)
    private val btnPrev = button(android.R.drawable.ic_media_previous) { prevAction() }
    private val btnPlay = button(android.R.drawable.ic_media_pause) { playAction() }
    private val btnNext = button(android.R.drawable.ic_media_next) { nextAction() }

    private val controls = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER
        listOf(btnPrev, btnPlay, btnNext).forEach {
            addView(it, LinearLayout.LayoutParams(px(56f), px(48f)).apply {
                marginStart = px(12f); marginEnd = px(12f)
            })
        }
    }

    private val expanded = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(px(18f), px(16f), px(18f), px(14f))
        alpha = 0f
        visibility = View.GONE

        val col = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            addView(eTitle)
            addView(eSub)
        }
        val top = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(eIcon, LinearLayout.LayoutParams(px(52f), px(52f)))
            addView(col, LinearLayout.LayoutParams(0, WRAP, 1f).apply {
                marginStart = px(12f); marginEnd = px(8f)
            })
            addView(eBars, LinearLayout.LayoutParams(px(24f), px(18f)))
        }
        addView(top, LinearLayout.LayoutParams(MATCH, WRAP))
        addView(controls, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = px(10f) })
    }

    private val gestures = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true
        override fun onSingleTapUp(e: MotionEvent): Boolean {
            tapAction(); return true
        }
        override fun onLongPress(e: MotionEvent) {
            longAction()
        }
        override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
            if (velocityY < -500) swipeUpAction() else if (velocityY > 500) tapAction()
            return true
        }
    })

    private var anim: ValueAnimator? = null

    init {
        pill.addView(compact, LayoutParams(idleW, idleH, Gravity.CENTER))
        pill.addView(expanded, LayoutParams(idleW, WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        addView(pill, LayoutParams(idleW, idleH, Gravity.CENTER_HORIZONTAL))
        pill.setOnTouchListener { _, e -> gestures.onTouchEvent(e) }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_OUTSIDE) {
            outsideAction()
            return true
        }
        return super.dispatchTouchEvent(ev)
    }

    // ================= public states =================

    fun showIdle() {
        ensureVisible()
        fade(compact, false)
        fade(expanded, false)
        cBars.playing = false
        eBars.playing = false
        morph(idleW, idleH, idleH / 2f)
    }

    /**
     * @param bars null = hidden, true = animating, false = static
     */
    fun showCompact(
        icon: Drawable?,
        label: CharSequence?,
        right: CharSequence?,
        rightColor: Int,
        bars: Boolean?,
        barColor: Int,
        wide: Boolean,
    ) {
        ensureVisible()
        cIcon.setImageDrawable(icon)
        cIcon.visibility = if (icon != null) View.VISIBLE else View.GONE
        cLabel.text = label ?: ""
        cLabel.visibility = if (label.isNullOrEmpty()) View.INVISIBLE else View.VISIBLE
        cRight.text = right ?: ""
        cRight.setTextColor(rightColor)
        cRight.visibility = if (right.isNullOrEmpty()) View.GONE else View.VISIBLE
        cBars.visibility = if (bars == null) View.GONE else View.VISIBLE
        cBars.color = barColor
        cBars.playing = bars == true
        eBars.playing = false

        val h = max(idleH, px(34f))
        val w = if (wide) min(expandedWidth(), px(300f)) else max(idleW + px(96f), px(180f))
        compact.layoutParams = (compact.layoutParams as LayoutParams).apply { width = w; height = h }

        fade(expanded, false)
        fade(compact, true)
        morph(w, h, h / 2f)
    }

    fun showExpanded(
        icon: Drawable?,
        title: CharSequence,
        sub: CharSequence,
        media: Boolean,
        playing: Boolean,
        barColor: Int,
    ) {
        ensureVisible()
        eIcon.setImageDrawable(icon)
        eIcon.visibility = if (icon != null) View.VISIBLE else View.GONE
        eTitle.text = title
        eSub.text = sub
        eSub.visibility = if (sub.isEmpty()) View.GONE else View.VISIBLE
        controls.visibility = if (media) View.VISIBLE else View.GONE
        eBars.visibility = if (media) View.VISIBLE else View.GONE
        eBars.color = barColor
        eBars.playing = media && playing
        cBars.playing = false
        btnPlay.setImageResource(
            if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        )

        val w = expandedWidth()
        val h = px(if (media) 168f else 96f)
        expanded.layoutParams = (expanded.layoutParams as LayoutParams).apply { width = w }

        fade(compact, false)
        fade(expanded, true)
        morph(w, h, 34f * density)
    }

    fun hideAll() {
        anim?.cancel()
        cBars.playing = false
        eBars.playing = false
        pill.animate().alpha(0f).setDuration(150).withEndAction {
            if (pill.alpha == 0f) pill.visibility = View.GONE
        }.start()
    }

    // ================= internals =================

    private fun expandedWidth(): Int =
        min(resources.displayMetrics.widthPixels - px(20f), px(420f))

    private fun ensureVisible() {
        if (pill.visibility != View.VISIBLE || pill.alpha < 1f) {
            pill.visibility = View.VISIBLE
            pill.animate().alpha(1f).setDuration(150).start()
        }
    }

    private fun morph(w: Int, h: Int, radius: Float) {
        val lp = pill.layoutParams
        val w0 = lp.width
        val h0 = lp.height
        val r0 = bg.cornerRadius
        if (w0 == w && h0 == h && r0 == radius) return
        anim?.cancel()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 480
            interpolator = OvershootInterpolator(1.1f)
            addUpdateListener { a ->
                val f = a.animatedValue as Float
                lp.width = max(1, (w0 + (w - w0) * f).toInt())
                lp.height = max(1, (h0 + (h - h0) * f).toInt())
                bg.cornerRadius = r0 + (radius - r0) * f.coerceIn(0f, 1f)
                pill.layoutParams = lp
            }
            start()
        }
    }

    private fun fade(v: View, show: Boolean) {
        if (show) {
            v.visibility = View.VISIBLE
            v.animate().alpha(1f).setStartDelay(140).setDuration(220).start()
        } else {
            if (v.visibility != View.VISIBLE) return
            v.animate().alpha(0f).setStartDelay(0).setDuration(100).withEndAction {
                if (v.alpha == 0f) v.visibility = View.GONE
            }.start()
        }
    }

    private fun rounded(v: View, r: Float) {
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, r)
            }
        }
        v.clipToOutline = true
    }

    private fun text(size: Float, color: Int, bold: Boolean) = TextView(context).apply {
        textSize = size
        setTextColor(color)
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun button(res: Int, click: () -> Unit) = ImageButton(context).apply {
        setImageResource(res)
        setColorFilter(Color.WHITE)
        background = null
        scaleType = ImageView.ScaleType.FIT_CENTER
        setOnClickListener { click() }
    }
}
