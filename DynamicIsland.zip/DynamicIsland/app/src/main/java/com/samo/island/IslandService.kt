package com.samo.island

import android.accessibilityservice.AccessibilityService
import android.app.ActivityOptions
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.media.session.PlaybackState
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

/**
 * Accessibility service used only to draw the island over every app and the status bar
 * (TYPE_ACCESSIBILITY_OVERLAY works on Samsung without "draw over other apps").
 */
class IslandService : AccessibilityService() {

    private var wm: WindowManager? = null
    private var island: IslandView? = null
    private var lp: WindowManager.LayoutParams? = null
    private var prefs: SharedPreferences? = null
    private val h = Handler(Looper.getMainLooper())

    private var media: IslandEvent.Media? = null
    private var temp: IslandEvent? = null      // notification / charging shown for a few seconds
    private var expanded = false
    private var receiverOn = false

    private val clearTemp = Runnable {
        temp = null; expanded = false; render()
    }
    private val collapse = Runnable {
        expanded = false
        if (temp != null) h.postDelayed(clearTemp, 1500)
        render()
    }

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        applyPrefs(); render()
    }

    private val powerReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val plugged = i.action == Intent.ACTION_POWER_CONNECTED
            onEvent(IslandEvent.Charging(batteryLevel(), plugged))
        }
    }

    // ---------------- lifecycle ----------------

    override fun onServiceConnected() {
        super.onServiceConnected()
        val w = getSystemService(WINDOW_SERVICE) as WindowManager
        wm = w
        val p = Prefs.get(this)
        prefs = p

        val v = IslandView(this)
        v.tapAction = { onTap() }
        v.longAction = { openCurrent() }
        v.outsideAction = {
            if (expanded) {
                h.removeCallbacks(collapse)
                collapse.run()
            }
        }
        v.swipeUpAction = { dismiss() }
        v.prevAction = {
            IslandBus.controller?.transportControls?.skipToPrevious()
            keepOpen()
        }
        v.nextAction = {
            IslandBus.controller?.transportControls?.skipToNext()
            keepOpen()
        }
        v.playAction = {
            val c = IslandBus.controller
            if (c != null) {
                if (c.playbackState?.state == PlaybackState.STATE_PLAYING) c.transportControls.pause()
                else c.transportControls.play()
            }
            keepOpen()
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            if (Build.VERSION.SDK_INT >= 30) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            } else if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        w.addView(v, params)
        island = v
        lp = params
        applyPrefs()
        p.registerOnSharedPreferenceChangeListener(prefListener)

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(powerReceiver, f, Context.RECEIVER_EXPORTED)
        else registerReceiver(powerReceiver, f)
        receiverOn = true

        IslandBus.listener = { onEvent(it) }
        media = IslandBus.lastMedia
        render()
    }

    override fun onDestroy() {
        IslandBus.listener = null
        h.removeCallbacksAndMessages(null)
        prefs?.unregisterOnSharedPreferenceChangeListener(prefListener)
        if (receiverOn) {
            try { unregisterReceiver(powerReceiver) } catch (e: Exception) { }
            receiverOn = false
        }
        island?.let { v -> try { wm?.removeViewImmediate(v) } catch (e: Exception) { } }
        island = null
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        render()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    // ---------------- logic ----------------

    private fun onEvent(e: IslandEvent) {
        val p = prefs ?: return
        when (e) {
            is IslandEvent.Notif -> if (p.getBoolean(Prefs.NOTIF, true)) showTemp(e, 4500)
            is IslandEvent.Charging -> if (p.getBoolean(Prefs.CHARGE, true)) showTemp(e, 3000)
            is IslandEvent.Media -> {
                media = if (p.getBoolean(Prefs.MEDIA, true)) e else null
                if (media == null && temp == null) expanded = false
                render()
            }
            IslandEvent.MediaGone -> {
                media = null
                if (temp == null) expanded = false
                render()
            }
        }
    }

    private fun showTemp(e: IslandEvent, ms: Long) {
        temp = e
        expanded = false
        h.removeCallbacks(clearTemp)
        h.removeCallbacks(collapse)
        h.postDelayed(clearTemp, ms)
        render()
    }

    private fun onTap() {
        val t = temp
        if (expanded) {
            if (t is IslandEvent.Notif) { openCurrent(); return }
            h.removeCallbacks(collapse); collapse.run()
            return
        }
        if (t is IslandEvent.Notif || (t == null && media != null)) {
            expanded = true
            h.removeCallbacks(clearTemp)
            keepOpen()
            render()
        }
    }

    private fun keepOpen() {
        h.removeCallbacks(collapse)
        h.postDelayed(collapse, 7000)
    }

    private fun dismiss() {
        h.removeCallbacks(clearTemp)
        h.removeCallbacks(collapse)
        temp = null
        expanded = false
        render()
    }

    private fun openCurrent() {
        val t = temp
        try {
            if (t is IslandEvent.Notif) {
                val pi = t.intent
                if (pi != null) sendPending(pi) else launch(t.pkg)
            } else {
                media?.let { launch(it.pkg) }
            }
        } catch (e: Exception) {
        }
        dismiss()
    }

    private fun sendPending(pi: PendingIntent) {
        val opts = if (Build.VERSION.SDK_INT >= 34) {
            ActivityOptions.makeBasic()
                .setPendingIntentBackgroundActivityStartMode(ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED)
                .toBundle()
        } else null
        pi.send(this, 0, null, null, null, null, opts)
    }

    private fun launch(pkg: String) {
        packageManager.getLaunchIntentForPackage(pkg)?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(it)
        }
    }

    private fun batteryLevel(): Int {
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    }

    private fun applyPrefs() {
        val p = prefs ?: return
        val v = island ?: return
        val params = lp ?: return
        val d = resources.displayMetrics.density
        params.y = (p.getInt(Prefs.Y, Prefs.DEF_Y) * d).toInt()
        params.x = (p.getInt(Prefs.X, Prefs.DEF_X) * d).toInt()
        v.idleW = (p.getInt(Prefs.IW, Prefs.DEF_IW) * d).toInt()
        v.idleH = (p.getInt(Prefs.IH, Prefs.DEF_IH) * d).toInt()
        try { wm?.updateViewLayout(v, params) } catch (e: Exception) { }
    }

    private fun render() {
        val v = island ?: return
        val p = prefs ?: return
        if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            v.hideAll(); return
        }
        val t = temp
        val m = media
        when {
            t is IslandEvent.Notif && expanded ->
                v.showExpanded(t.icon, t.title, t.text, media = false, playing = false, barColor = Color.WHITE)

            t is IslandEvent.Notif ->
                v.showCompact(t.icon, t.title, null, Color.WHITE, bars = null, barColor = Color.WHITE, wide = true)

            t is IslandEvent.Charging -> {
                val color = when {
                    t.plugged -> GREEN
                    t.level <= 20 -> RED
                    else -> Color.WHITE
                }
                val label = if (t.plugged) "⚡ يتم الشحن" else "تم فصل الشاحن"
                v.showCompact(null, label, "${t.level}%", color, bars = null, barColor = color, wide = true)
            }

            m != null && expanded ->
                v.showExpanded(artOf(m), m.title, m.artist, media = true, playing = m.playing, barColor = m.color)

            m != null ->
                v.showCompact(artOf(m), null, null, Color.WHITE, bars = m.playing, barColor = m.color, wide = false)

            p.getBoolean(Prefs.IDLE, true) -> v.showIdle()

            else -> v.hideAll()
        }
    }

    private fun artOf(m: IslandEvent.Media): Drawable? =
        m.art?.let { BitmapDrawable(resources, it) }
            ?: try { packageManager.getApplicationIcon(m.pkg) } catch (e: Exception) { null }

    companion object {
        private val GREEN = Color.parseColor("#30D158")
        private val RED = Color.parseColor("#FF453A")
    }
}
