package com.samo.island

import android.app.Activity
import android.content.Intent
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val prefs by lazy { Prefs.get(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.btnAcc).setOnClickListener {
            open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.btnNotif).setOnClickListener {
            open(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        findViewById<Button>(R.id.btnBattery).setOnClickListener {
            open(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }

        bindSeek(R.id.seekY, R.id.lblY, "البعد عن أعلى الشاشة", Prefs.Y, Prefs.DEF_Y, 0, 60)
        bindSeek(R.id.seekX, R.id.lblX, "الإزاحة يمين / يسار", Prefs.X, Prefs.DEF_X, -60, 60)
        bindSeek(R.id.seekW, R.id.lblW, "عرض الجزيرة", Prefs.IW, Prefs.DEF_IW, 40, 200)
        bindSeek(R.id.seekH, R.id.lblH, "ارتفاع الجزيرة", Prefs.IH, Prefs.DEF_IH, 18, 50)

        bindSwitch(R.id.swIdle, Prefs.IDLE)
        bindSwitch(R.id.swNotif, Prefs.NOTIF)
        bindSwitch(R.id.swMedia, Prefs.MEDIA)
        bindSwitch(R.id.swCharge, Prefs.CHARGE)

        findViewById<Button>(R.id.btnTestNotif).setOnClickListener {
            if (!checkRunning()) return@setOnClickListener
            IslandBus.post(
                IslandEvent.Notif(
                    title = "رسالة جديدة",
                    text = "أهلاً! الجزيرة الديناميكية شغالة 🎉 اضغط عليها لتكبر",
                    icon = applicationInfo.loadIcon(packageManager),
                    intent = null,
                    pkg = packageName,
                )
            )
        }
        findViewById<Button>(R.id.btnTestCharge).setOnClickListener {
            if (!checkRunning()) return@setOnClickListener
            val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
            IslandBus.post(IslandEvent.Charging(bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY), true))
        }
    }

    override fun onResume() {
        super.onResume()
        val acc = isAccessibilityOn()
        val notif = isNotifAccessOn()
        findViewById<TextView>(R.id.statusAcc).text = if (acc) "✅ مفعّلة" else "❌ غير مفعّلة"
        findViewById<TextView>(R.id.statusNotif).text = if (notif) "✅ مسموح" else "❌ غير مسموح"
    }

    private fun checkRunning(): Boolean {
        if (!IslandBus.serviceRunning) {
            Toast.makeText(this, "فعّل خدمة الجزيرة أولاً", Toast.LENGTH_SHORT).show()
            return false
        }
        return true
    }

    private fun isAccessibilityOn(): Boolean {
        val list = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return list.split(':').any {
            it.startsWith("$packageName/") && it.endsWith("IslandService")
        }
    }

    private fun isNotifAccessOn(): Boolean {
        val list = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return list.split(':').any { it.startsWith("$packageName/") }
    }

    private fun open(i: Intent) {
        try {
            startActivity(i)
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun bindSeek(seekId: Int, labelId: Int, title: String, key: String, def: Int, min: Int, max: Int) {
        val seek = findViewById<SeekBar>(seekId)
        val label = findViewById<TextView>(labelId)
        val cur = prefs.getInt(key, def).coerceIn(min, max)
        seek.max = max - min
        seek.progress = cur - min
        label.text = "$title: $cur"
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, progress: Int, fromUser: Boolean) {
                val v = progress + min
                label.text = "$title: $v"
                if (fromUser) prefs.edit().putInt(key, v).apply()
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
    }

    @Suppress("DEPRECATION")
    private fun bindSwitch(id: Int, key: String) {
        val sw = findViewById<Switch>(id)
        sw.isChecked = prefs.getBoolean(key, true)
        sw.setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(key, checked).apply() }
    }
}
