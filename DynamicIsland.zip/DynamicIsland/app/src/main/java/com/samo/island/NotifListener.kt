package com.samo.island

import android.app.Notification
import android.app.NotificationManager
import android.content.ComponentName
import android.graphics.Bitmap
import android.graphics.Color
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Feeds notifications and the currently playing media into the island. */
class NotifListener : NotificationListenerService() {

    private val main = Handler(Looper.getMainLooper())
    private var sessions: MediaSessionManager? = null
    private var controller: MediaController? = null
    private val lastShown = HashMap<String, String>()

    private val mediaCallback = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) = pushMedia()
        override fun onMetadataChanged(metadata: MediaMetadata?) = pushMedia()
        override fun onSessionDestroyed() = attach(null)
    }

    private val sessionsChanged = MediaSessionManager.OnActiveSessionsChangedListener { list ->
        pick(list)
    }

    // ---------------- media ----------------

    override fun onListenerConnected() {
        super.onListenerConnected()
        val msm = getSystemService(MediaSessionManager::class.java) ?: return
        sessions = msm
        val me = ComponentName(this, NotifListener::class.java)
        try {
            msm.addOnActiveSessionsChangedListener(sessionsChanged, me, main)
            pick(msm.getActiveSessions(me))
        } catch (e: SecurityException) {
        }
    }

    override fun onListenerDisconnected() {
        try {
            sessions?.removeOnActiveSessionsChangedListener(sessionsChanged)
        } catch (e: Exception) {
        }
        attach(null)
        super.onListenerDisconnected()
    }

    private fun pick(list: List<MediaController>?) {
        val playing = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
        attach(playing ?: list?.firstOrNull())
    }

    private fun attach(c: MediaController?) {
        if (c != null && controller?.sessionToken == c.sessionToken) {
            pushMedia(); return
        }
        try {
            controller?.unregisterCallback(mediaCallback)
        } catch (e: Exception) {
        }
        controller = c
        c?.registerCallback(mediaCallback, main)
        IslandBus.controller = c
        pushMedia()
    }

    private fun pushMedia() {
        val c = controller
        val md = c?.metadata
        val state = c?.playbackState?.state
        if (c == null || md == null || state == null ||
            state == PlaybackState.STATE_STOPPED || state == PlaybackState.STATE_NONE ||
            state == PlaybackState.STATE_ERROR
        ) {
            IslandBus.post(IslandEvent.MediaGone)
            return
        }
        val art = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        val title = md.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE) ?: ""
        val artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
        IslandBus.post(
            IslandEvent.Media(
                title = title,
                artist = artist,
                art = art,
                color = accent(art),
                playing = state == PlaybackState.STATE_PLAYING || state == PlaybackState.STATE_BUFFERING,
                pkg = c.packageName,
            )
        )
    }

    /** Brightened average colour of the album art, used for the equalizer bars. */
    private fun accent(b: Bitmap?): Int {
        if (b == null) return Color.WHITE
        return try {
            val p = Bitmap.createScaledBitmap(b, 1, 1, true).getPixel(0, 0)
            val hsv = FloatArray(3)
            Color.colorToHSV(p, hsv)
            hsv[1] = (hsv[1] * 1.3f).coerceAtMost(1f)
            hsv[2] = hsv[2].coerceAtLeast(0.85f)
            Color.HSVToColor(hsv)
        } catch (e: Exception) {
            Color.WHITE
        }
    }

    // ---------------- notifications ----------------

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        if (sbn.isOngoing) return
        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (n.category == Notification.CATEGORY_TRANSPORT) return

        // Skip silent / low-priority notifications
        val ranking = NotificationListenerService.Ranking()
        if (currentRanking?.getRanking(sbn.key, ranking) == true &&
            ranking.importance < NotificationManager.IMPORTANCE_DEFAULT
        ) return

        val ex = n.extras ?: return
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim()
        if (title.isNullOrEmpty()) return
        val text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString()?.trim() ?: ""

        // Don't re-show the same notification when the app just updates it
        val sig = "$title|$text"
        if (lastShown[sbn.key] == sig) return
        if (lastShown.size > 300) lastShown.clear()
        lastShown[sbn.key] = sig

        val icon = try {
            n.getLargeIcon()?.loadDrawable(this)
        } catch (e: Exception) {
            null
        } ?: try {
            packageManager.getApplicationIcon(sbn.packageName)
        } catch (e: Exception) {
            null
        }

        IslandBus.post(IslandEvent.Notif(title, text, icon, n.contentIntent, sbn.packageName))
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        lastShown.remove(sbn.key)
    }
}
